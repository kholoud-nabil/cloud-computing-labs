import matplotlib.pyplot as plt


percentages = ['50%', '66%', '75%', '80%', '90%', '95%', '98%', '99%', '100%']
latencies = [80, 140, 171, 204, 259, 357, 531, 577, 577]

plt.figure(figsize=(10, 6))
plt.bar(percentages, latencies, color='salmon', edgecolor='black')


plt.title('Response Time Distribution (Tail Latency)')
plt.xlabel('Percentile of Requests')
plt.ylabel('Response Time (ms)')


for i, v in enumerate(latencies):
    plt.text(i, v + 5, str(v), ha='center', fontweight='bold')

plt.grid(axis='y', linestyle='--', alpha=0.7)


plt.savefig('tail_latency_chart.png')
print("تم حفظ المخطط بنجاح باسم: tail_latency_chart.png")
plt.show()