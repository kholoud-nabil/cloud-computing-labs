from flask import Flask
app = Flask(__name__)

@app.route("/")
def home():
    return "Hello from Lab 3"

@app.route("/health")
def health():
    return "ok"

app.run(host="0.0.0.0", port=5000)